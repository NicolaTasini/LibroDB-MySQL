package com.Tasini.DemoDBH2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoDbH2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
