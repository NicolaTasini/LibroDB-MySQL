package com.Tasini.DemoDBH2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoDbH2Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoDbH2Application.class, args);
	}

}
